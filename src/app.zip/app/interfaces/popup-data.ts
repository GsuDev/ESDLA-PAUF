import { ButtonSeverity } from 'primeng/button';

export interface PopupData {
  message: string;
  header?: string;
  nameButton: string;
  severity: ButtonSeverity;
}
