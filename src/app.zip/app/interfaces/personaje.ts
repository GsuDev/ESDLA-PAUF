export interface Personaje {
  id: number;
  nombre: string;
  raza: string;
  fechaNacimiento: string;
  nivelCorrupcion: number;
  fechaBaja: string | null;
}
