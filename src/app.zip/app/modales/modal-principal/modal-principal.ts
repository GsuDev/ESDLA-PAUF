import { Component } from '@angular/core';

@Component({
  selector: 'app-modal-principal',
  imports: [],
  templateUrl: './modal-principal.html',
  styleUrl: './modal-principal.css',
})
export class ModalPrincipal {

}
